#!/usr/bin/env python3
"""
تجربة واجهة الفلاتر مع قيود المستخدم العادي
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import tkinter as tk
from config.user_session import UserSession
from new_activity_filter_system import NewActivityFilterSystem

def create_sample_data():
    """إنشاء بيانات تجريبية"""
    return [
        {
            'التاريخ': '2024-01-15',
            'الوقت': '10:30',
            'نوع العملية': 'إدخال',
            'اسم العنصر': 'مسامير حديد 10مم',
            'التصنيف': 'مواد البناء',
            'الكمية المضافة': '100',
            'الكمية المسحوبة': '0',
            'الرصيد': '100',
            'اسم المستخدم': 'سارة محمد',
            'رقم المشروع': '102',
            'التفاصيل': 'إضافة مخزون جديد'
        },
        {
            'التاريخ': '2024-01-15',
            'الوقت': '11:00',
            'نوع العملية': 'سحب',
            'اسم العنصر': 'أسمنت أبيض 50كغ',
            'التصنيف': 'مواد البناء',
            'الكمية المضافة': '0',
            'الكمية المسحوبة': '5',
            'الرصيد': '45',
            'اسم المستخدم': 'أحمد علي',
            'رقم المشروع': '103',
            'التفاصيل': 'استخدام في العمل'
        },
        {
            'التاريخ': '2024-01-15',
            'الوقت': '12:15',
            'نوع العملية': 'تعديل',
            'اسم العنصر': 'مثقاب كهربائي',
            'التصنيف': 'أدوات',
            'الكمية المضافة': '2',
            'الكمية المسحوبة': '0',
            'الرصيد': '7',
            'اسم المستخدم': 'سارة محمد',
            'رقم المشروع': '102',
            'التفاصيل': 'تصحيح الكمية - إضافة 2'
        },
        {
            'التاريخ': '2024-01-15',
            'الوقت': '14:30',
            'نوع العملية': 'سحب',
            'اسم العنصر': 'طلاء أبيض 4لتر',
            'التصنيف': 'مواد التشطيب',
            'الكمية المضافة': '0',
            'الكمية المسحوبة': '3',
            'الرصيد': '12',
            'اسم المستخدم': 'محمد حسن',
            'رقم المشروع': '101',
            'التفاصيل': 'للاستخدام في الطابق الثاني'
        },
        {
            'التاريخ': '2024-01-15',
            'الوقت': '15:45',
            'نوع العملية': 'إدخال',
            'اسم العنصر': 'مفاتيح كهربائية',
            'التصنيف': 'كهربائيات',
            'الكمية المضافة': '20',
            'الكمية المسحوبة': '0',
            'الرصيد': '35',
            'اسم المستخدم': 'سارة محمد',
            'رقم المشروع': '102',
            'التفاصيل': 'شحنة جديدة من المورد'
        }
    ]

def test_regular_user_interface():
    """تجربة واجهة المستخدم العادي"""
    print("🔴 اختبار واجهة المستخدم العادي...")
    
    # إنشاء جلسة مستخدم عادي
    user_session = UserSession()
    user_session.login("سارة محمد", 102, is_admin=False)
    
    # إنشاء النافذة الرئيسية
    root = tk.Tk()
    root.title("اختبار قيود الفلاتر - مستخدم عادي")
    root.geometry("800x600")
    
    try:
        # إنشاء نظام الفلاتر
        filter_system = NewActivityFilterSystem(
            parent=root, 
            sheets_manager=None,  # لن نحتاج لاتصال فعلي
            current_user=user_session.username
        )
        
        # تعيين جلسة المستخدم
        filter_system.user_session = user_session
        
        # تحميل البيانات التجريبية
        filter_system.all_operations = create_sample_data()
        
        # تطبيق الفلاتر لعرض البيانات المناسبة
        filter_system.apply_filters()
        
        # إظهار معلومات عن الفلاتر
        info_text = f"""
قيود المستخدم العادي:
• اسم المستخدم: {user_session.username}
• رقم المشروع: {user_session.project_number}
• نوع المستخدم: مستخدم عادي

الفلاتر المقيدة:
• فلتر المستخدم: مقيد على '{user_session.username}'
• فلتر المشروع: مقيد على '{user_session.project_number}'

الفلاتر القابلة للتعديل:
• فلتر التصنيف: يمكن تغييره
• فلتر العنصر: يمكن تغييره

سيتم عرض {len(filter_system.displayed_operations)} عملية فقط من أصل {len(filter_system.all_operations)} عملية
        """
        
        # إضافة نص توضيحي
        info_label = tk.Label(
            root, 
            text=info_text, 
            justify=tk.LEFT, 
            bg="lightblue", 
            font=("Arial", 9)
        )
        info_label.pack(fill=tk.X, padx=10, pady=5)
        
        print(f"✅ تم إنشاء الواجهة")
        print(f"📊 البيانات المعروضة: {len(filter_system.displayed_operations)} من أصل {len(filter_system.all_operations)}")
        
        # تشغيل النافذة
        print("\n🖥️ افتح النافذة لرؤية الواجهة مع القيود المطبقة")
        print("   • فلاتر المستخدم والمشروع ستظهر معطلة")
        print("   • فلاتر التصنيف والعنصر ستظهر قابلة للتعديل")
        print("   • البيانات المعروضة ستكون مقتصرة على المستخدم والمشروع الحالي")
        print("\n⚠️ اضغط Ctrl+C في المحطة لإغلاق النافذة")
        
        root.mainloop()
        
    except Exception as e:
        print(f"❌ خطأ: {e}")
        root.destroy()
        raise

def test_admin_interface():
    """تجربة واجهة المدير"""
    print("\n🔵 اختبار واجهة المدير...")
    
    # إنشاء جلسة مدير
    admin_session = UserSession()
    admin_session.login("Admin User", 999, is_admin=True)
    
    # إنشاء النافذة الرئيسية
    root = tk.Tk()
    root.title("اختبار الفلاتر - مدير")
    root.geometry("800x600")
    
    try:
        # إنشاء نظام الفلاتر
        filter_system = NewActivityFilterSystem(
            parent=root, 
            sheets_manager=None,
            current_user=admin_session.username
        )
        
        # تعيين جلسة المستخدم
        filter_system.user_session = admin_session
        
        # تحميل البيانات التجريبية
        filter_system.all_operations = create_sample_data()
        
        # تطبيق الفلاتر
        filter_system.apply_filters()
        
        # إظهار معلومات عن الفلاتر
        info_text = f"""
صلاحيات المدير:
• اسم المستخدم: {admin_session.username}
• رقم المشروع: {admin_session.project_number}
• نوع المستخدم: مدير

جميع الفلاتر متاحة:
• فلتر المستخدم: يمكن تغييره لأي مستخدم
• فلتر المشروع: يمكن تغييره لأي مشروع
• فلتر التصنيف: يمكن تغييره
• فلتر العنصر: يمكن تغييره

سيتم عرض جميع العمليات: {len(filter_system.displayed_operations)}
        """
        
        # إضافة نص توضيحي
        info_label = tk.Label(
            root, 
            text=info_text, 
            justify=tk.LEFT, 
            bg="lightgreen", 
            font=("Arial", 9)
        )
        info_label.pack(fill=tk.X, padx=10, pady=5)
        
        print(f"✅ تم إنشاء واجهة المدير")
        print(f"📊 البيانات المعروضة: {len(filter_system.displayed_operations)}")
        
        # تشغيل النافذة
        print("\n🖥️ افتح النافذة لرؤية واجهة المدير")
        print("   • جميع الفلاتر ستظهر قابلة للتعديل")
        print("   • جميع البيانات ستكون مرئية")
        print("\n⚠️ اضغط Ctrl+C في المحطة لإغلاق النافذة")
        
        root.mainloop()
        
    except Exception as e:
        print(f"❌ خطأ: {e}")
        root.destroy()
        raise

if __name__ == "__main__":
    print("🧪 تجربة واجهة الفلاتر مع القيود")
    print("=" * 50)
    
    choice = input("اختر نوع المستخدم للاختبار:\n1. مستخدم عادي (قيود مطبقة)\n2. مدير (بدون قيود)\nاختر (1 أو 2): ")
    
    try:
        if choice == "1":
            test_regular_user_interface()
        elif choice == "2":
            test_admin_interface()
        else:
            print("❌ اختيار غير صحيح")
            
    except KeyboardInterrupt:
        print("\n\n👋 تم إغلاق الاختبار")
    except Exception as e:
        print(f"\n❌ خطأ: {e}")
        import traceback
        traceback.print_exc()