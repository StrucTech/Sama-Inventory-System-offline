"""
Google Sheets integration package for the Inventory Management System.
"""

from .manager import SheetsManager

__all__ = ['SheetsManager']